#TOPSIS

Submitted By: Reena Arora - 102017169.

Type: Package.

Title: TOPSIS method for multiple-criteria decision making (MCDM).

Version: 1.0.4.

Date: 2023-01-22.

Author: Reena Arora.

Maintainer: Reena Arora rarora_be20@thapar.edu.

Description: Evaluation of alternatives based on multiple criteria using TOPSIS method..